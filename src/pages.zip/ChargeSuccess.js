import React,{Component} from 'react';
import '../Css/MainStyle.css'
import {NavLink} from 'react-router-dom';

const ChargeSuccess=()=>(
    <div>
        
    </div>
)

export default ChargeSuccess